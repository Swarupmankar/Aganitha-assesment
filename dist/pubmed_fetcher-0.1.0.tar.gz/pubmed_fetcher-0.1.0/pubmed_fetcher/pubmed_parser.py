
import requests
import xmltodict
from .utils import is_non_academic_affiliation, extract_email

def search_pubmed(query, api_key, retmax=20):
    base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    params = {
        "db": "pubmed",
        "term": query,
        "retmode": "json",
        "retmax": retmax,
        "api_key": api_key
    }
    res = requests.get(base_url, params=params)
    res.raise_for_status()
    data = res.json()
    return data["esearchresult"]["idlist"]

def fetch_details(pmids, api_key):
    url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
    params = {
        "db": "pubmed",
        "id": ",".join(pmids),
        "retmode": "xml",
        "api_key": api_key
    }
    res = requests.get(url, params=params)
    res.raise_for_status()
    articles = xmltodict.parse(res.content)["PubmedArticleSet"]["PubmedArticle"]
    if isinstance(articles, dict):
        articles = [articles]
    return articles

def parse_article(article):
    medline = article["MedlineCitation"]
    pmid = medline["PMID"]["#text"] if isinstance(medline["PMID"], dict) else medline["PMID"]
    article_data = medline.get("Article", {})
    title = article_data.get("ArticleTitle", "")
    pub_date = medline.get("DateCompleted") or article_data.get("Journal", {}).get("JournalIssue", {}).get("PubDate", {})
    date_str = "-".join([pub_date.get("Year", "0000"), pub_date.get("Month", "01"), pub_date.get("Day", "01")])

    authors = article_data.get("AuthorList", {}).get("Author", [])
    if isinstance(authors, dict):
        authors = [authors]

    non_academic_authors = []
    companies = set()
    corresponding_email = ""

    for author in authors:
        affiliation = ""
        if "AffiliationInfo" in author:
            aff_info = author["AffiliationInfo"]
            if isinstance(aff_info, list):
                affiliation = aff_info[0].get("Affiliation", "")
            else:
                affiliation = aff_info.get("Affiliation", "")

        if is_non_academic_affiliation(affiliation):
            name = f"{author.get('ForeName', '')} {author.get('LastName', '')}".strip()
            non_academic_authors.append(name)
            companies.add(affiliation)

        if not corresponding_email:
            corresponding_email = extract_email(affiliation)

    if not non_academic_authors:
        return None
   
    return {
        "PubmedID": pmid,
        "Title": title,
        "Publication Date": date_str,
        "Non-academicAuthor(s)": "; ".join(non_academic_authors),
        "CompanyAffiliation(s)": "; ".join(companies),
        "Corresponding Author Email": corresponding_email
    }
